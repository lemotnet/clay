./ethdcrminer64 -epool europe.ethash-hub.miningpoolhub.com:20535 -ewal dualminerru.dualminerru -epsw x -mode 1 -dbg -1 -mport 0 -etha 0 -ftime 55 -retrydelay 1 -tt 79 -ttli 77 -tstop 89 -esm 2

